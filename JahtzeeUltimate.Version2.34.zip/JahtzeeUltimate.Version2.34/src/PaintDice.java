import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Ayettey on 2015-11-10.
 */
class CreateDices {


    static String[] yatzy = { "C", "O", "O", "L", "!" };
    static JButton rollDices = new JButton("R");
    static int nrOfDices = 5;
    static ArrayList<JButton> dices = new ArrayList<>();
    static ArrayList<Integer> diceClickedOrNot = new ArrayList();
    static int[] valueOfDice = new int[5];



    static void CreatingDices(){

        int possition = 20;
        int i = 0;

        while (i < nrOfDices) {

            dices.add(new JButton());
            dices.get(i).setForeground(Color.red.darker());
             dices.get(i).setText(yatzy[i]);
            dices.get(i).setBounds(possition, 5, 107, 107); // (PlaceringX, PlaceringY, StorlekX, StorlekY)
            dices.get(i).setFont(new Font("", Font.BOLD, 120));
            dices.get(i).setBackground(new Color(22, 103, 0));
            dices.get(i).setBorder(null);
            dices.get(i).setFocusPainted(false);
            dices.get(i).addActionListener(Layout.buttonListener);
            Layout.mainPanel.add(dices.get(i));

            i++;
            possition = possition + 110;
        }

        i = 0;

        while (i < nrOfDices) {
            diceClickedOrNot.add(0);
            i++;
        }
    }

}

class DiceEngine {




    static ImageIcon icon = new ImageIcon();


    static void RandomNumber(int index) {
         int random;
        Random rand = new Random();
        random = rand.nextInt(6) + 1;

        icon = new ImageIcon("/Users/toota/Downloads/YatzyMaster-master-6/src/DiceImage/dice"+random+".png");
        CreateDices.dices.get(index).setText("");
        CreateDices.dices.get(index).setIcon(icon);
        //CreatePlayer.players.get(index).valueOfDice[index] = random;
        CreateDices.valueOfDice[index] = random;
        System.out.println(random );

    }
}
