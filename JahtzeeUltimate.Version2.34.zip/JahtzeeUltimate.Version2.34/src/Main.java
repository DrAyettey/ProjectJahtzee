

public class Main {

    public static void main(String[] args) {
/**
 * How to Play

 Goal

 Score as many points as possible by rolling different dice combinations.

 Gameplay
 Rolling the Dice
 In each turn you get 3 dice rolls, and after each one (except the last) you can either score the dice or roll again some, or all, the dice. To select which dice to keep, tick the checkbox (the small square), with the "Keep" caption, adjacent to it.

 Scoring
 You score the dice by clicking the button with the caption of the desired category.

 The board is dived to two sections: upper and lower. In the upper section there are six categories, corresponding to each die face. When scoring in the upper section you get the total of dice with the same face as the category. For example, when scoring in the "Threes" you get the sum of all the threes in your dice.

 Scoring in lower section is a bit different. Each category has different scoring rules. In the "3 of a kind" you get the sum of the die faces if you have 3 (at least) dice with the same face. The "4 of a kind" is scored the same as the previous but requiring 4 dice with the same face to be entitled to get the points.

 The "Full House" gives you 25 points if you have 3 dice with with the same face and also the remaining 2 dice with the same face (not necessarily the same as the 3).

 The "Sequence of 4" gives you 30 points if you have a sequence of 4 consecutive die faces. The "Sequence of 5" is like the previous but gives you 40 points and requires a sequence of 5 dice.

 "Yahtzee" gives you 50 points if all the dice have the same face.

 "Chance" gives you the sum of all die faces without any requirements.

 If you score the dice in a category which they don't meet the requirements, you get 0 points.

 Yahtzee Joker
 If you roll a Yahtzee (5 of a kind), and you already filled the "Yahtzee" category (either with 50 or 0 points), you may score it anywhere in the lower section (that you haven't scored in already) and receive points for it as if the dice qualified the requirements.

 Bonuses
 If the total of the points in the upper sections is 63 points or more, you get 35 bonus points.

 If you already scored a Yahtzee in the appropriate section, any additional yahtzee you score automatically gives you a bonus of 100 points.

 End of Game
 The game ends when all 13 categories have been scored. You final score is the total of all the points in the different categories and bonuses you received.
 */

        new AddPlayer();
        //new PlayerLayout();
    }
}
