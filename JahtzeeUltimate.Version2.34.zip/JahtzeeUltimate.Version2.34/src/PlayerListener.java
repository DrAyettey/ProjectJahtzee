import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Ayettey on 2015-11-19.
 */
public class PlayerListener implements ActionListener {

    static int i = 0;
    AddPlayer listOfPlayers;

    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == AddPlayer.addPlayer&&AddPlayer.input.getText().trim().toUpperCase().equals("")) {


                JOptionPane.showMessageDialog(null, "The text input must not be left empty",
                        "Yahtzee Alert", JOptionPane.PLAIN_MESSAGE);
                System.out.print("Working list");


        }


        if( e.getSource() == AddPlayer.addPlayer&&!AddPlayer.input.getText().trim().toUpperCase().equals("")) {

                AddPlayer.addTable.setEnabled(true);
                AddPlayer.rowData[i][1] = AddPlayer.input.getText().toUpperCase();
                AddPlayer.addTable.setEnabled(false);
                AddPlayer.input.setText("  ");
                AddPlayer.startTheGame.setEnabled(true);
                i++;
                AddPlayer.playerCounter.setText(i + "/6");

        }







        if (e.getSource() == AddPlayer.startTheGame)  {




                new Layout();
                AddPlayer.playerFrame.dispose();

                CreatePlayer.CreatingPlayers(listOfPlayers.checkPlayers);
                System.out.print("start game");

            }


        if (i == listOfPlayers.checkPlayers) {
                AddPlayer.addPlayer.setEnabled(false);

                //JOptionPane.showConfirmDialog(null, "The limit of Players is only up to "
                //     +listOfPlayers. checkPlayers+"\n Press play to continue",
                //  "Yahtzee Alert", JOptionPane.PLAIN_MESSAGE);
                // System.out.print("Yes man");
            }

           // if (e.getSource() == AddPlayer.startTheGame) {


              //  new Layout();
              //  AddPlayer.playerFrame.dispose();

               // CreatePlayer.CreatingPlayers(listOfPlayers.checkPlayers);
           // }
       /*
       while(i < 6) {
            if (e.getSource() == CreatePlayerButtons.playerButtons.get(i)) {
                i++;
                new Layout();
      }           PlayerLayout.playerFrame.dispose();
                CreatePlayer.CreatingPlayers(i);
            }
            i++;
        }
        */
        }

    }
