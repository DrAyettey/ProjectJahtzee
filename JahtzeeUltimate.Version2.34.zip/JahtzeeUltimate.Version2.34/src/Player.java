import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.ArrayList;


public class Player {

     Object rowData[][] = new Object[19][1];
     Object columnNames[] = { "Column One" };
     JTable table = new JTable(rowData, columnNames);



}

class CreatePlayer {

    static ArrayList<Player> players = new ArrayList<>();
    static byte i = 0;
    static byte j = 1;
    static int position = 203;

    static void CreatingPlayers(int nrOfPlayers) {

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );

        while (i < PlayerListener.i) {

            // create a new player every time a new player is added
            players.add(new Player());
            players.get(i).table.setRowHeight(28);
            players.get(i).table.setBounds(position, 160,94,530); //
            players.get(i).table.setFont(new Font("", Font.CENTER_BASELINE, 18));
            players.get(i).table.setBackground(Color.WHITE); // bakgrund
            players.get(i).table.setEnabled(false); // gör att den inte går att reigera
            players.get(i).table.addMouseListener(Layout.mouseListener);
            players.get(i).table.setBorder(BorderFactory.createLineBorder(Color.cyan.brighter(), 1));
            players.get(i).table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // centrerar text
            players.get(i).rowData[0][0] = AddPlayer.rowData[i][1].trim();
            players.get(i).table.setGridColor(Color.black);
            Layout.mainPanel.add(players.get(i).table);
            position = position + 97;

            j++;
            i++;
        }
        players.get(RulesOfTheGame.turn).table.setBorder(BorderFactory.createLineBorder(Color.red.darker(), 2));
        players.get(RulesOfTheGame.turn).table.setGridColor(Color.black);
    }
}
