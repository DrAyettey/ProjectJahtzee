import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Ayettey on 2015-11-09.
 */
public class EventListener implements ActionListener {

    int i = 0;
    int j = 0;
    int diceCounter;
    static int spins = 0;
    static int throwsLeft = 3;
    static Boolean nextPlayer = false;








    @Override
    public void actionPerformed(ActionEvent e) {
        Object scr = e.getSource();

        i = 0;
        while (i < CreateDices.nrOfDices){

            if (e.getSource() == CreateDices.dices.get(i)) {

                if (CreateDices.diceClickedOrNot.get(i) == 1) {
                    CreateDices.dices.get(i).setIcon(DiceEngine.icon = new ImageIcon("/Users/toota/Downloads/YatzyMaster-master-6/src/DiceImage/dice"+CreateDices.valueOfDice[i]+".png"));
                    CreateDices.diceClickedOrNot.set(i, 0);
                    diceCounter++;

                }

                else if (CreateDices.diceClickedOrNot.get(i) == 0) {
                    CreateDices.dices.get(i).setIcon(DiceEngine.icon = new ImageIcon("/Users/toota/Downloads/YatzyMaster-master-6/src/DiceImage/dice"+CreateDices.valueOfDice[i]+".png"));
                    CreateDices.diceClickedOrNot.set(i, 1);
                    diceCounter--;
                }
                System.out.println(CreateDices.diceClickedOrNot);
            }
            i++;
        }


        if (e.getSource() == Layout.rollDices) {
            j = 0;
            spins++;
            throwsLeft--;

            if (throwsLeft>0) {
                Layout.throwsLeft.setText("Throw left is:\n " + throwsLeft + "  ");
            }
            else {
                Layout.throwsLeft.setText("Your turn is over!");
                Layout.rollDices.setEnabled(false);
            }


            if (spins <= 3 && nextPlayer == false) {
                while (j < 5) {
                    if (CreateDices.diceClickedOrNot.get(j) == 0) {
                        DiceEngine.RandomNumber(j);
                    }
                    j++;

                    if (nextPlayer == true){

                        nextPlayer = false;
                    }
                }
            }
        }

    }
}

