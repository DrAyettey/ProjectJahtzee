import javax.swing.*;
import java.awt.*;

/**
 * Created by Ayettey on 2015-11-19.
 */
public class PlayerLayout extends JFrame {

        static JPanel playerPanel = new JPanel();
        static PlayerListener playerButtonListener = new PlayerListener();
        static JFrame playerFrame = new JFrame();

        public PlayerLayout() {
            super();
            createFrame();
        }

        public void createFrame() {



            playerPanel.setLayout(null);
            playerPanel.setBackground(new Color(22, 103, 0));
            playerFrame.add(playerPanel); //

            CreatePlayerButtons.CreatingPlayersButtons();




            playerFrame.setSize(1450, 1700);
            playerFrame.setTitle("Yahtzee");
            playerFrame.setDefaultCloseOperation(PlayerLayout.DISPOSE_ON_CLOSE);
            playerFrame.setLocationRelativeTo(null);
            playerFrame.setVisible(true);
            playerFrame.setResizable(false);

        }

    }
