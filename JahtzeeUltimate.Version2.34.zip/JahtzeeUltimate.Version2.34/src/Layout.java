import javax.swing.*;
import java.awt.*;

public class Layout extends JFrame {

    static Object rowData[][] = { { "  Name"},     { "  Once"       }, { "  Twos"       },{ "  Threes" },
                                  { "  Fours" },   { "  Fives"      }, { "  Sixes"      },{ "  Sum"  },
                                  { "  Bonus" },   { "  Pair"       }, { "  Two of kind"},{ "  Three of kind" },
                                  { "  Four of kind"},{"  Small str" },  { "  Big str" },   { "  Full hs"    },
                                  { "  Chance"   }, { "  Yahtzee"    }, { "   Total"      }};
    static JLabel help = new JLabel("Yahtzee Help :");
    static Object columnNames[] = { "Column One" };
    static JTable table = new JTable(rowData, columnNames);
    static JPanel mainPanel = new JPanel();
    static JButton rollDices = new JButton(" CAST DICE");
    static JLabel playerName = new JLabel("  PLAYERS: "+ AddPlayer.rowData[0][1].trim().toUpperCase()+"  ");
    static JLabel throwsLeft = new JLabel("  Your chances are 3 ");

    static EventListener buttonListener = new EventListener();
    static MouseEventListener mouseListener = new MouseEventListener();
    static JFrame mainFrame = new JFrame();

    public Layout() {
        super();
        createFrame();
    }

    public void createFrame() {



        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.cyan.darker().darker());
        mainFrame.add(mainPanel);

        CreateDices.CreatingDices();

        help.setBounds(18, 100, 160, 50);
        help.setOpaque(false);
        help.setFont(new Font("", Font.CENTER_BASELINE, 10));
        help.setHorizontalAlignment(SwingConstants.RIGHT);
        mainPanel.add(help);

        rollDices.setBounds(250, 112, 100, 50);
        rollDices.setFont(new Font("", Font.BOLD, 10));
        rollDices.setBackground(Color.green);

        rollDices.setFocusPainted(true);
        rollDices.addActionListener(buttonListener);
        mainPanel.add(rollDices);

        playerName.setBounds(53, 120, 600, 50);
        playerName.setOpaque(false);

        playerName.setFont(new Font("", Font.CENTER_BASELINE, 16));
        playerName.setHorizontalAlignment(SwingConstants.LEFT);
        mainPanel.add(playerName);

        throwsLeft.setBounds(400, 100, 200, 50);
        throwsLeft.setOpaque(false);
        throwsLeft.setFont(new Font("", Font.CENTER_BASELINE, 14));
        throwsLeft.setHorizontalAlignment(SwingConstants.RIGHT);
        mainPanel.add(throwsLeft);


        table.setRowHeight(28); // höjd på raderna
        table.setBounds(60,160,140,530); // possition och storlek
        table.setFont(new Font("", Font.CENTER_BASELINE, 16)); // font och storlek
        table.setBackground(Color.WHITE); // bakgrund
        table.setGridColor(Color.black);
        table.setBorder(BorderFactory.createLineBorder(Color.BLACK,2)); // HERE
        table.setFocusable(true);
        table.setEnabled(false);
        mainPanel.add(table);



        // lägger in en bild i JFrame
        // ImageIcon icon = new ImageIcon("D://Desctop//dice6.png");
        // JLabel label = new JLabel(icon);
        // label.setBounds(10,10,300,300);// possition och storlek




        // mainPanel.add(new JLabel(new ImageIcon()));


        mainFrame.setSize(600, 730);
        mainFrame.setTitle("Yahtzee");
        mainFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
        mainFrame.setResizable(true);

    }

}
