import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by Ayettey on 2015-12-05.
 */
public class AddPlayer extends JFrame {

    static String rowData[][] = {{"  PLAYER 1:", ""}, {" PLAYER 2:", ""}, {"  PLAYER 3:", ""}, {"  PLAYER 4:", ""}, {"  PLAYER 5:", ""}, {"  PLAYER 6:", ""}};
    static String columnNames[] = {"", ""};
    static JLabel yahtzeeTitle;
    static JPanel playerPanel = new JPanel();
    static PlayerListener playerButtonListener = new PlayerListener();
    static JFrame playerFrame = new JFrame();
    static JTable addTable = new JTable(rowData, columnNames);
    static JTextField input = new JTextField();
    static JButton addPlayer = new JButton();
    static JButton startTheGame = new JButton();
    static JLabel inputText = new JLabel();
    static JLabel tableText = new JLabel();
    static JLabel playerCounter = new JLabel();
    public static int checkPlayers=0;
    //static Object[] optionList = {"1", "2", "3", "4"};
    static  String value;
    static ArrayList<String> players = new ArrayList<>();


    public AddPlayer() {
        super();
        createFrame();
      //System.out.print( DiceEngine.random);

    }

    public void createFrame() {





            //numberOfPlayers.add(1,number);



            playerPanel.setLayout(null);
            playerPanel.setBackground(Color.cyan.darker());
            playerFrame.add(playerPanel); // lägger in mainpanel i Jframe

            yahtzeeTitle=new JLabel( new ImageIcon("/Users/toota/Downloads/YatzyMaster-master-6/src/DiceImage/small.png"));
            yahtzeeTitle.setBounds(100, 440, 220, 100);
            playerPanel.add(yahtzeeTitle);
            inputText.setText("Enter Your  Name:");
            inputText.setBounds(54, 2, 800, 100);
            inputText.setFont(new Font("", Font.CENTER_BASELINE, 20));
            playerPanel.add(inputText);

            tableText.setText("List Of Players:");
            tableText.setBounds(54, 150, 800, 100);
            tableText.setFont(new Font("", Font.CENTER_BASELINE, 20));

            playerPanel.add(tableText);

            playerCounter.setText("0/6");
            playerCounter.setBounds(54, 1130, 100, 100);
            playerCounter.setFont(new Font("", Font.CENTER_BASELINE, 20));
            playerPanel.add(playerCounter);

            addTable.setRowHeight(50);
            addTable.setBounds(54, 220, 500, 200);
            addTable.setFont(new Font("", Font.CENTER_BASELINE, 18));
            addTable.setBackground(Color.WHITE);
            addTable.setBorder(BorderFactory.createLineBorder(Color.cyan.brighter(), 1)); // HERE
            addTable.setGridColor(Color.GRAY);


            playerPanel.add(addTable);

            input.setBounds(54, 70, 500, 100);
            input.setCaretColor(Color.CYAN.darker());
            input.setFont(new Font("", Font.CENTER_BASELINE, 30));
            input.setText(" ");
            playerPanel.add(input);

            addPlayer.setBounds(455, 165, 100, 50);
            addPlayer.setFont(new Font("", Font.CENTER_BASELINE, 18));
            addPlayer.setText("ADD");
            addPlayer.addActionListener(playerButtonListener);
            playerPanel.add(addPlayer);

            startTheGame.setBounds(450, 418, 108, 80);
            startTheGame.setFont(new Font("", Font.CENTER_BASELINE, 18));
            startTheGame.setText("PLAY!");
            startTheGame.setEnabled(false);
            startTheGame.addActionListener(playerButtonListener);
            playerPanel.add(startTheGame);












        playerFrame.setSize(600 ,600);
        playerFrame.setTitle("YATHZEE");
        playerFrame.setDefaultCloseOperation(PlayerLayout.DISPOSE_ON_CLOSE);
        playerFrame.setLocationRelativeTo(null); //Centrerar fönstret mitt på skärmen
        playerFrame.setVisible(true);
        playerFrame.setResizable(false);


        players.add("1");
        players.add("2");
        players.add("3");
        players.add("4");

        Object[] options = players.toArray();


        value = (String) JOptionPane.showInputDialog(null,
                "Select Players?\n",
                "Dialog Confirmation",
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        int index = players.indexOf(value);


        // checkPlayers = Integer.parseInt(value);

        int numPlayers = 0;
        if ( value  != null &&  value .length() == 1)
            checkPlayers = Integer.parseInt( value );
        if (checkPlayers < 1 || checkPlayers > 4)
            System.exit(0);







    }
    }



