
import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Created byAyettey on 2015-11-23.
 */
public class MouseEventListener implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent e) {

        int row = CreatePlayer.players.get(0).table.rowAtPoint(e.getPoint());
        int i = 0;


        if (row == 18 || row == 7|| row == 8 || CreateDices.valueOfDice[1] == 0){

        }
        else {

            if (RulesOfTheGame.RuleSelector(row) == 0) {
                JOptionPane.showMessageDialog(null, "Wrong cell kindly choice a right cell",
                        "Alert", JOptionPane.PLAIN_MESSAGE);
            }
            else  if (RulesOfTheGame.RuleSelector(row) >= 1){
                EventListener.nextPlayer = true;
                CreatePlayer.players.get(RulesOfTheGame.turn).table.setEnabled(true);
                CreatePlayer.players.get(RulesOfTheGame.turn).rowData[row][0] = RulesOfTheGame.RuleSelector(row);
                CreatePlayer.players.get(RulesOfTheGame.turn).table.setEnabled(false);


                RulesOfTheGame.RuleSumAndBunus();
              // r�kna total po�ng
                RulesOfTheGame.RuleTotal();
                // startar metod f�r att byta spelare
                RulesOfTheGame.WhosTurn();

                RulesOfTheGame.ResetDice();

            }
        }



    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {


    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
